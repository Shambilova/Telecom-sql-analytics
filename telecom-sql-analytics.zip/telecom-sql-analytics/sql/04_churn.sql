-- ============================================================
-- 04. ОТТОК (CHURN)
-- churn rate месяца = ушедшие в месяце / активные на начало месяца
-- ============================================================

-- Q: Помесячный churn rate (CTE + коррелированные подзапросы по календарю месяцев)
WITH months AS (
    SELECT DISTINCT month AS m_start,
           date(month, '+1 month') AS m_end
    FROM clean_usage
),
base AS (
    SELECT
        m.m_start,
        (SELECT COUNT(*) FROM clean_customers c
          WHERE c.activation_date < m.m_start
            AND (c.churn_date IS NULL OR c.churn_date >= m.m_start))   AS active_start,
        (SELECT COUNT(*) FROM clean_customers c
          WHERE c.churn_date >= m.m_start AND c.churn_date < m.m_end)  AS churned
    FROM months m
)
SELECT m_start AS month, active_start, churned,
       ROUND(100.0 * churned / active_start, 2) AS churn_rate_pct
FROM base
WHERE m_start < '2025-12-01'          -- декабрь неполный: отток за его пределами не виден
ORDER BY m_start;

-- Q: Churn по тарифам за 2025 год
SELECT
    t.tariff_name,
    COUNT(*)                                                     AS customers,
    SUM(CASE WHEN c.churn_date < '2026-01-01' THEN 1 ELSE 0 END) AS churned,
    ROUND(100.0 * SUM(CASE WHEN c.churn_date < '2026-01-01' THEN 1 ELSE 0 END) / COUNT(*), 1) AS churn_pct
FROM clean_customers c
JOIN tariffs t ON t.tariff_id = c.tariff_id
WHERE c.activation_date < '2026-01-01'
GROUP BY t.tariff_id, t.tariff_name
ORDER BY churn_pct DESC;

-- Q: Churn по возрастным группам
SELECT
    CASE WHEN age < 25 THEN '18-24'
         WHEN age < 35 THEN '25-34'
         WHEN age < 50 THEN '35-49'
         WHEN age IS NULL THEN 'нет данных'
         ELSE '50+' END                                           AS age_group,
    COUNT(*)                                                      AS customers,
    ROUND(100.0 * AVG(CASE WHEN churn_date < '2026-01-01' THEN 1.0 ELSE 0 END), 1) AS churn_pct
FROM clean_customers
GROUP BY age_group
ORDER BY age_group;

-- Q: Связь обращений в поддержку и оттока
WITH ticket_cnt AS (
    SELECT customer_id, COUNT(*) AS tickets
    FROM support_tickets
    GROUP BY customer_id
)
SELECT
    CASE WHEN COALESCE(tc.tickets, 0) >= 3 THEN '3+'
         ELSE CAST(COALESCE(tc.tickets, 0) AS TEXT) END           AS tickets_bucket,
    COUNT(*)                                                      AS customers,
    ROUND(100.0 * AVG(CASE WHEN c.churn_date < '2026-01-01' THEN 1.0 ELSE 0 END), 1) AS churn_pct
FROM clean_customers c
LEFT JOIN ticket_cnt tc ON tc.customer_id = c.customer_id
GROUP BY tickets_bucket
ORDER BY tickets_bucket;

-- Q: Категории обращений: объём и скорость решения
SELECT category,
       COUNT(*)                     AS tickets,
       ROUND(AVG(resolved_days), 1) AS avg_days_to_resolve
FROM support_tickets
GROUP BY category
ORDER BY tickets DESC;
