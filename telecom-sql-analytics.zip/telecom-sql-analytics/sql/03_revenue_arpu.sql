-- ============================================================
-- 03. ВЫРУЧКА И ARPU
-- ARPU = выручка за период / число уникальных абонентов с начислениями
-- ============================================================

-- Q: Ключевые метрики за 2025 год
SELECT
    COUNT(DISTINCT customer_id)                  AS paying_customers,
    ROUND(SUM(revenue) / 1e6, 1)                 AS revenue_mln_kzt,
    ROUND(SUM(revenue) / COUNT(DISTINCT customer_id) / 12, 0) AS avg_monthly_arpu_kzt
FROM clean_usage;

-- Q: Динамика выручки и ARPU по месяцам + изменение к прошлому месяцу (LAG)
WITH monthly AS (
    SELECT month,
           COUNT(DISTINCT customer_id) AS subscribers,
           SUM(revenue)                AS revenue
    FROM clean_usage
    GROUP BY month
)
SELECT
    month,
    subscribers,
    ROUND(revenue / 1e6, 2)                                     AS revenue_mln,
    ROUND(revenue / subscribers, 0)                             AS arpu,
    ROUND(100.0 * (revenue - LAG(revenue) OVER (ORDER BY month))
          / LAG(revenue) OVER (ORDER BY month), 2)              AS revenue_mom_pct
FROM monthly
ORDER BY month;

-- Q: ARPU и выручка по тарифам (JOIN + GROUP BY)
SELECT
    t.tariff_name,
    t.monthly_fee,
    COUNT(DISTINCT u.customer_id)               AS customers,
    ROUND(SUM(u.revenue) / 1e6, 2)              AS revenue_mln,
    ROUND(AVG(u.revenue), 0)                    AS arpu,
    ROUND(100.0 * (AVG(u.revenue) - t.monthly_fee) / t.monthly_fee, 1) AS overage_uplift_pct
FROM clean_usage u
JOIN clean_customers c ON c.customer_id = u.customer_id
JOIN tariffs t         ON t.tariff_id   = c.tariff_id
GROUP BY t.tariff_id, t.tariff_name, t.monthly_fee
ORDER BY revenue_mln DESC;

-- Q: ARPU по регионам и сегментам
SELECT
    r.region_name,
    c.segment,
    COUNT(DISTINCT c.customer_id)  AS customers,
    ROUND(AVG(u.revenue), 0)       AS arpu
FROM clean_usage u
JOIN clean_customers c ON c.customer_id = u.customer_id
JOIN regions r         ON r.region_id   = c.region_id
GROUP BY r.region_name, c.segment
ORDER BY r.region_name, c.segment;

-- Q: Кандидаты на апсейл: 3+ месяцев с превышением лимита интернета (HAVING)
SELECT
    c.customer_id,
    t.tariff_name,
    t.data_gb_limit,
    SUM(CASE WHEN u.data_gb > t.data_gb_limit THEN 1 ELSE 0 END) AS months_over_limit,
    ROUND(AVG(u.data_gb), 1)                                     AS avg_gb
FROM clean_usage u
JOIN clean_customers c ON c.customer_id = u.customer_id
JOIN tariffs t         ON t.tariff_id   = c.tariff_id
WHERE t.tariff_id < 4                       -- на Премиуме апгрейдить некуда
GROUP BY c.customer_id, t.tariff_name, t.data_gb_limit
HAVING months_over_limit >= 3
ORDER BY months_over_limit DESC, avg_gb DESC
LIMIT 10;
