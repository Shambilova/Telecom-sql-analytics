-- ============================================================
-- 05. ПАРЕТО: какие сегменты дают 80% выручки
-- Оконные функции: SUM() OVER, ROW_NUMBER, накопительная доля
-- ============================================================

-- Q: Сегменты (регион x тариф), дающие 80% выручки
WITH seg AS (
    SELECT r.region_name, t.tariff_name, SUM(u.revenue) AS revenue
    FROM clean_usage u
    JOIN clean_customers c ON c.customer_id = u.customer_id
    JOIN regions r         ON r.region_id   = c.region_id
    JOIN tariffs t         ON t.tariff_id   = c.tariff_id
    GROUP BY r.region_name, t.tariff_name
),
cum AS (
    SELECT *,
           ROW_NUMBER() OVER (ORDER BY revenue DESC)                           AS rnk,
           SUM(revenue) OVER (ORDER BY revenue DESC)                           AS cum_revenue,
           SUM(revenue) OVER ()                                                AS total_revenue
    FROM seg
)
SELECT rnk, region_name, tariff_name,
       ROUND(revenue / 1e6, 2)                      AS revenue_mln,
       ROUND(100.0 * revenue / total_revenue, 1)    AS share_pct,
       ROUND(100.0 * cum_revenue / total_revenue, 1) AS cum_share_pct
FROM cum
WHERE 100.0 * (cum_revenue - revenue) / total_revenue < 80   -- включаем сегмент, пересекающий порог 80%
ORDER BY rnk;

-- Q: Топ-3 клиента по выручке в каждом регионе (ROW_NUMBER + PARTITION BY)
WITH cust_rev AS (
    SELECT c.customer_id, c.region_id, SUM(u.revenue) AS revenue
    FROM clean_usage u
    JOIN clean_customers c ON c.customer_id = u.customer_id
    GROUP BY c.customer_id, c.region_id
),
ranked AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY region_id ORDER BY revenue DESC) AS rn
    FROM cust_rev
)
SELECT r.region_name, ranked.rn AS place, ranked.customer_id, ROUND(ranked.revenue, 0) AS revenue_kzt
FROM ranked
JOIN regions r ON r.region_id = ranked.region_id
WHERE ranked.rn <= 3
ORDER BY r.region_name, ranked.rn;

-- Q: Доля клиентов, дающих 50% выручки (концентрация)
WITH cust_rev AS (
    SELECT customer_id, SUM(revenue) AS revenue FROM clean_usage GROUP BY customer_id
),
cum AS (
    SELECT revenue,
           SUM(revenue) OVER (ORDER BY revenue DESC) AS cum_rev,
           SUM(revenue) OVER ()                      AS total,
           ROW_NUMBER() OVER (ORDER BY revenue DESC) AS rn,
           COUNT(*) OVER ()                          AS n
    FROM cust_rev
)
SELECT MIN(rn) AS customers_for_50pct_revenue,
       n       AS total_customers,
       ROUND(100.0 * MIN(rn) / n, 1) AS share_of_customers_pct
FROM cum
WHERE cum_rev >= 0.5 * total;
