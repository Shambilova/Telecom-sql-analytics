-- ============================================================
-- 01. ПРОВЕРКА КАЧЕСТВА ДАННЫХ
-- Измерения: completeness, uniqueness, validity, consistency
-- ============================================================

-- Q: Completeness. Пропуски в ключевых полях monthly_usage
SELECT
    COUNT(*)                                          AS total_rows,
    SUM(CASE WHEN revenue  IS NULL THEN 1 ELSE 0 END) AS null_revenue,
    SUM(CASE WHEN data_gb  IS NULL THEN 1 ELSE 0 END) AS null_data_gb,
    ROUND(100.0 * SUM(CASE WHEN revenue IS NULL THEN 1 ELSE 0 END) / COUNT(*), 3) AS null_revenue_pct
FROM monthly_usage;

-- Q: Uniqueness. Дубликаты по бизнес-ключу (клиент + месяц)
SELECT customer_id, month, COUNT(*) AS cnt
FROM monthly_usage
GROUP BY customer_id, month
HAVING COUNT(*) > 1
ORDER BY cnt DESC, customer_id
LIMIT 10;

-- Q: Validity. Отрицательный или аномально большой трафик
SELECT
    SUM(CASE WHEN data_gb < 0    THEN 1 ELSE 0 END) AS negative_gb,
    SUM(CASE WHEN data_gb > 1000 THEN 1 ELSE 0 END) AS outlier_gb_over_1000
FROM monthly_usage;

-- Q: Validity. Некорректный возраст клиентов
SELECT age, COUNT(*) AS customers
FROM customers
WHERE age < 14 OR age > 100
GROUP BY age
ORDER BY age;

-- Q: Consistency. Дата отключения раньше даты подключения
SELECT customer_id, activation_date, churn_date
FROM customers
WHERE churn_date < activation_date;

-- Q: Referential integrity. Использование без клиента (ожидаем 0 строк)
SELECT COUNT(*) AS orphan_usage_rows
FROM monthly_usage u
LEFT JOIN customers c ON c.customer_id = u.customer_id
WHERE c.customer_id IS NULL;

-- Q: Сводка: какую долю данных мы отбрасываем при очистке
WITH ranked AS (
    SELECT usage_id, data_gb, revenue,
           ROW_NUMBER() OVER (PARTITION BY customer_id, month ORDER BY usage_id) AS rn
    FROM monthly_usage
)
SELECT
    COUNT(*)                                                                 AS rows_before,
    SUM(CASE WHEN rn = 1 AND data_gb BETWEEN 0 AND 1000 AND revenue IS NOT NULL
             THEN 1 ELSE 0 END)                                              AS rows_after,
    ROUND(100.0 * SUM(CASE WHEN rn > 1 OR data_gb NOT BETWEEN 0 AND 1000 OR revenue IS NULL
                           THEN 1 ELSE 0 END) / COUNT(*), 3)                 AS dropped_pct
FROM ranked;
