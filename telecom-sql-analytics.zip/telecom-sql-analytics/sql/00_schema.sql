-- Схема учебной базы телеком-оператора (SQLite)
PRAGMA foreign_keys = ON;

CREATE TABLE regions (
    region_id   INTEGER PRIMARY KEY,
    region_name TEXT NOT NULL
);

CREATE TABLE tariffs (
    tariff_id     INTEGER PRIMARY KEY,
    tariff_name   TEXT NOT NULL,
    monthly_fee   INTEGER NOT NULL,   -- абонплата, тенге
    data_gb_limit INTEGER NOT NULL,   -- включённый интернет, ГБ
    minutes_limit INTEGER NOT NULL    -- включённые минуты
);

CREATE TABLE customers (
    customer_id     INTEGER PRIMARY KEY,
    region_id       INTEGER NOT NULL REFERENCES regions(region_id),
    tariff_id       INTEGER NOT NULL REFERENCES tariffs(tariff_id),
    segment         TEXT NOT NULL,    -- B2C / B2B
    age             INTEGER,
    activation_date TEXT NOT NULL,    -- дата подключения
    churn_date      TEXT              -- дата отключения, NULL = активный
);

-- Одна строка = один клиент за один месяц
CREATE TABLE monthly_usage (
    usage_id    INTEGER PRIMARY KEY,
    customer_id INTEGER NOT NULL REFERENCES customers(customer_id),
    month       TEXT NOT NULL,        -- первое число месяца, YYYY-MM-01
    data_gb     REAL,
    minutes     INTEGER,
    sms         INTEGER,
    revenue     REAL                  -- выручка за месяц, тенге
);

CREATE TABLE support_tickets (
    ticket_id     INTEGER PRIMARY KEY,
    customer_id   INTEGER NOT NULL REFERENCES customers(customer_id),
    created_date  TEXT NOT NULL,
    category      TEXT NOT NULL,
    resolved_days INTEGER
);

CREATE INDEX idx_usage_customer ON monthly_usage(customer_id);
CREATE INDEX idx_usage_month    ON monthly_usage(month);
CREATE INDEX idx_tickets_cust   ON support_tickets(customer_id);
