-- ============================================================
-- 02. ОЧИЩЕННЫЕ ПРЕДСТАВЛЕНИЯ (витрины, на которых строится анализ)
-- Правила очистки описаны в docs/data_dictionary.md
-- ============================================================

DROP VIEW IF EXISTS clean_usage;
CREATE VIEW clean_usage AS
SELECT usage_id, customer_id, month, data_gb, minutes, sms, revenue
FROM (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY customer_id, month ORDER BY usage_id) AS rn
    FROM monthly_usage
)
WHERE rn = 1                           -- убираем дубликаты
  AND data_gb BETWEEN 0 AND 1000       -- убираем отрицательные значения и выбросы
  AND revenue IS NOT NULL;             -- убираем строки без выручки

DROP VIEW IF EXISTS clean_customers;
CREATE VIEW clean_customers AS
SELECT customer_id, region_id, tariff_id, segment,
       CASE WHEN age BETWEEN 14 AND 100 THEN age END AS age,             -- невалидный возраст -> NULL
       activation_date,
       CASE WHEN churn_date >= activation_date THEN churn_date END AS churn_date  -- невалидный отток -> NULL
FROM customers;
