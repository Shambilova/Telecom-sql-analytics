-- ============================================================
-- 06. КОГОРТНЫЙ АНАЛИЗ RETENTION
-- Когорта = месяц первого начисления у клиентов, подключённых в 2025 году
-- retention(k) = клиенты, активные на k-й месяц жизни / размер когорты
-- ============================================================

-- Q: Retention по когортам (месяцы 0-5)
WITH first_month AS (
    SELECT u.customer_id, MIN(u.month) AS cohort
    FROM clean_usage u
    JOIN clean_customers c ON c.customer_id = u.customer_id
    WHERE c.activation_date >= '2025-01-01'
    GROUP BY u.customer_id
),
activity AS (
    SELECT f.cohort,
           (CAST(strftime('%Y', u.month) AS INT) - CAST(strftime('%Y', f.cohort) AS INT)) * 12
         + (CAST(strftime('%m', u.month) AS INT) - CAST(strftime('%m', f.cohort) AS INT)) AS month_idx,
           COUNT(DISTINCT u.customer_id) AS active
    FROM first_month f
    JOIN clean_usage u ON u.customer_id = f.customer_id
    GROUP BY f.cohort, month_idx
),
sizes AS (
    SELECT cohort, COUNT(*) AS cohort_size FROM first_month GROUP BY cohort
)
SELECT
    s.cohort,
    s.cohort_size,
    ROUND(100.0 * MAX(CASE WHEN a.month_idx = 0 THEN a.active END) / s.cohort_size, 1) AS m0,
    ROUND(100.0 * MAX(CASE WHEN a.month_idx = 1 THEN a.active END) / s.cohort_size, 1) AS m1,
    ROUND(100.0 * MAX(CASE WHEN a.month_idx = 2 THEN a.active END) / s.cohort_size, 1) AS m2,
    ROUND(100.0 * MAX(CASE WHEN a.month_idx = 3 THEN a.active END) / s.cohort_size, 1) AS m3,
    ROUND(100.0 * MAX(CASE WHEN a.month_idx = 4 THEN a.active END) / s.cohort_size, 1) AS m4,
    ROUND(100.0 * MAX(CASE WHEN a.month_idx = 5 THEN a.active END) / s.cohort_size, 1) AS m5
FROM sizes s
JOIN activity a ON a.cohort = s.cohort
GROUP BY s.cohort, s.cohort_size
ORDER BY s.cohort;
