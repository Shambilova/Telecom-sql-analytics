"""Выполняет все запросы из sql/*.sql и сохраняет результаты в docs/results.md.
Запуск: python scripts/run_queries.py
"""
import sqlite3, os, re, glob

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
con = sqlite3.connect(os.path.join(ROOT, "data", "telecom.db"))

# сначала создаём представления
con.executescript(open(os.path.join(ROOT, "sql", "02_clean_views.sql"), encoding="utf-8").read())

def md_table(cols, rows, limit=40):
    out = ["| " + " | ".join(cols) + " |", "|" + "|".join("---" for _ in cols) + "|"]
    for r in rows[:limit]:
        out.append("| " + " | ".join("" if v is None else str(v) for v in r) + " |")
    if len(rows) > limit:
        out.append(f"\n_... показано {limit} из {len(rows)} строк_")
    return "\n".join(out)

lines = ["# Результаты запросов\n", "_Файл создаётся автоматически скриптом `scripts/run_queries.py`._\n"]
for path in sorted(glob.glob(os.path.join(ROOT, "sql", "0[1-9]_*.sql"))):
    if path.endswith("02_clean_views.sql"):
        continue
    text = open(path, encoding="utf-8").read()
    lines.append(f"\n## {os.path.basename(path)}\n")
    for block in re.split(r"(?m)^-- Q: ", text)[1:]:
        title, _, sql = block.partition("\n")
        cur = con.execute(sql.strip().rstrip(";"))
        rows = cur.fetchall()
        lines += [f"\n### {title.strip()}\n", md_table([d[0] for d in cur.description], rows), ""]
open(os.path.join(ROOT, "docs", "results.md"), "w", encoding="utf-8").write("\n".join(lines))
print("OK: docs/results.md")
