"""Генерация синтетического датасета телеком-оператора и загрузка в SQLite.
Данные вымышленные, никакого отношения к реальным клиентам не имеют.
Запуск: python scripts/generate_data.py
"""
import random, sqlite3, csv, os
from datetime import date, timedelta

random.seed(42)
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB = os.path.join(ROOT, "data", "telecom.db")
N_CUSTOMERS = 5000
MONTHS = [date(2025, m, 1) for m in range(1, 13)]

regions = ["Алматы", "Астана", "Шымкент", "Караганда", "Актобе", "Атырау", "Костанай", "Павлодар"]
region_w = [30, 22, 12, 7, 7, 6, 8, 8]
tariffs = [  # id, name, fee, gb, minutes
    (1, "Эконом", 2000, 5, 300),
    (2, "Стандарт", 4000, 20, 1000),
    (3, "Комфорт", 6500, 50, 2000),
    (4, "Премиум", 10000, 150, 5000),
]
# базовая вероятность оттока в месяц по тарифам
churn_p = {1: 0.030, 2: 0.020, 3: 0.012, 4: 0.007}
tariff_w = [35, 35, 20, 10]

customers, usage, tickets = [], [], []
tid = 0
for cid in range(1, N_CUSTOMERS + 1):
    reg = random.choices(range(1, 9), region_w)[0]
    tar = random.choices([1, 2, 3, 4], tariff_w)[0]
    seg = random.choices(["B2C", "B2B"], [88, 12])[0]
    age = random.randint(18, 70)
    act = date(2023, 1, 1) + timedelta(days=random.randint(0, 1094))
    churn = None
    fee, gb_lim, min_lim = tariffs[tar - 1][2:]
    tickets_n = 0
    for m in MONTHS:
        if act > m + timedelta(days=27):
            continue
        if churn and churn <= m:
            break
        # чем больше обращений, тем выше риск оттока
        p = churn_p[tar] * (1 + 0.5 * tickets_n)
        gb = max(0.0, random.gauss(gb_lim * 0.6, gb_lim * 0.35))
        mins = max(0, int(random.gauss(min_lim * 0.5, min_lim * 0.3)))
        sms = max(0, int(random.gauss(40, 30)))
        over = max(0, gb - gb_lim) * 100 + max(0, mins - min_lim) * 2
        rev = round(fee + over, 2)
        usage.append((None, cid, m.isoformat(), round(gb, 2), mins, sms, rev))
        if random.random() < 0.06:
            tid += 1
            tickets_n += 1
            tickets.append((tid, cid, (m + timedelta(days=random.randint(0, 27))).isoformat(),
                            random.choice(["Качество связи", "Биллинг", "Тариф", "Интернет", "Другое"]),
                            random.randint(0, 9)))
        if random.random() < p:
            churn = m + timedelta(days=random.randint(28, 59))
    customers.append((cid, reg, tar, seg, age, act.isoformat(), churn.isoformat() if churn else None))

# --- намеренно «грязные» данные для проверок качества ---
usage_dirty = list(usage)
for r in random.sample(usage, 15):                       # дубликаты (клиент, месяц)
    usage_dirty.append(r)
for i in random.sample(range(len(usage_dirty)), 10):     # отрицательный трафик
    r = list(usage_dirty[i]); r[3] = -abs(r[3]) - 1; usage_dirty[i] = tuple(r)
for i in random.sample(range(len(usage_dirty)), 12):     # пропущенная выручка
    r = list(usage_dirty[i]); r[6] = None; usage_dirty[i] = tuple(r)
for i in random.sample(range(len(usage_dirty)), 3):      # выброс по трафику
    r = list(usage_dirty[i]); r[3] = 9999.0; usage_dirty[i] = tuple(r)
customers_dirty = list(customers)
for i in random.sample(range(len(customers_dirty)), 5):  # отток раньше активации
    c = list(customers_dirty[i]); c[6] = "2022-06-01"; customers_dirty[i] = tuple(c)
for i in random.sample(range(len(customers_dirty)), 8):  # некорректный возраст
    c = list(customers_dirty[i]); c[4] = random.choice([0, 5, 150, 999]); customers_dirty[i] = tuple(c)
usage = [(i + 1,) + r[1:] for i, r in enumerate(usage_dirty)]

if os.path.exists(DB): os.remove(DB)
con = sqlite3.connect(DB)
with open(os.path.join(ROOT, "sql", "00_schema.sql"), encoding="utf-8") as f:
    con.executescript(f.read())
con.executemany("INSERT INTO regions VALUES (?,?)", list(enumerate(regions, 1)))
con.executemany("INSERT INTO tariffs VALUES (?,?,?,?,?)", tariffs)
con.executemany("INSERT INTO customers VALUES (?,?,?,?,?,?,?)", customers_dirty)
con.executemany("INSERT INTO monthly_usage VALUES (?,?,?,?,?,?,?)", usage)
con.executemany("INSERT INTO support_tickets VALUES (?,?,?,?,?)", tickets)
con.commit()

# CSV-копии для импорта в Power BI / Excel
for t in ["regions", "tariffs", "customers", "monthly_usage", "support_tickets"]:
    cur = con.execute(f"SELECT * FROM {t}")
    with open(os.path.join(ROOT, "data", f"{t}.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow([d[0] for d in cur.description]); w.writerows(cur)
    print(t, con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0])
con.close()
